
  # iOS-native voice assistant design

  This is a code bundle for iOS-native voice assistant design. The original project is available at https://www.figma.com/design/4DVnoVA8RiQzIoncJjFBEQ/iOS-native-voice-assistant-design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  